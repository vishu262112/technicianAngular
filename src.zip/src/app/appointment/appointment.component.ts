import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AppointmentService } from '../appointment.service';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css']
})
export class AppointmentComponent implements OnInit {

  appointmentForm:any;
  appointments:any;

  constructor( private fb:FormBuilder,private as:AppointmentService) { 
    this.appointmentForm= this.fb.group({
      patientId:[''],
      testId:[''],
      appointmentDate:[''],
      testSlot:[''],
      doctorId:['']
      
    });

  }

  get form()
  {
    return this.appointmentForm.controls;
  }

  ngOnInit(): void {
  }

  getAllAppointment()
  {
    this.as.getAllAppointment().subscribe((data)=>{
      console.log(data);
      this.appointments=data;
    })
  }

  getAppointment()
  {
    var appointment = this.appointmentForm.value;
    this.as.addAppointment(appointment).subscribe((data)=>{
      console.log(data);
      this.getAllAppointment();
    });
  }
}
