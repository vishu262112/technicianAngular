import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { TechnicianService } from '../technician.service';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements OnInit {

  technicianForm:any;
  technicians:any;

  constructor(private fb:FormBuilder,private ts:TechnicianService) { 
    this.technicianForm= this.fb.group({
      technicianId:[''],
      technicianFirstName:['vishwas'],
      technicianLastName:['ms'],
      technicianPhoneNumber:['9898989'],
      technicianEmailId:['visj@gmail.com']
     
    
    });
  }

  get form()
  {
    return this.technicianForm.controls;
  }

  ngOnInit(): void {
  }

  getAllTechnician()
  {
    this.ts.getAllTechnician().subscribe((data)=>{
      console.log(data);
      this.technicians= data;
    })
  }


  techAdd()
  {
    var technician = this.technicianForm.value;
    this.ts.addTechnician(technician).subscribe((data)=>{
      console.log(data);
      this.getAllTechnician();
    });
  }
    techModify()
    {
      var technician = this.technicianForm.value;
      this.ts.modifyTechnician(technician).subscribe((data)=>{
        console.log(data);
        this.getAllTechnician();
      });
    }

    techDelete()
    {
      var technicianId = this.technicianForm.controls.technicianId.value;
      this.ts.deleteTechnician(technicianId).subscribe((data)=>{
        console.log(data);
        this.getAllTechnician();
      });
    }
  }


