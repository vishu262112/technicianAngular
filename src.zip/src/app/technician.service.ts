import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TechnicianService {

  url:string='http://localhost:8080/technician/';

  constructor(private http:HttpClient) { }

  getAllTechnician()
  {
    return this.http.get(this.url);
  }

  findTechnicianById(technicianId:string)
  {
    return this.http.get(this.url+technicianId);
  }

  addTechnician(technician:any)
  {
    return this.http.post(this.url,technician);
  }

  modifyTechnician(technician:any)
  {
    return this.http.put(this.url,technician)
  }

  deleteTechnician(technicianId:string)
  {
    return this.http.delete(this.url+technicianId)
  }
}
