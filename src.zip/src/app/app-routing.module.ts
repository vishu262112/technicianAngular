import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthRouteGuardService } from './auth-route-guard.service';
import { DisplayComponent } from './display/display.component';
import { LoginComponent } from './login/login.component';
import { TechnicianComponent } from './technician/technician.component';

const routes: Routes = [
  {path:'login',component:LoginComponent,outlet:'col2'},
  {path:'technician',component:TechnicianComponent,outlet:'col2',canActivate:[AuthRouteGuardService]} ,
  {path:'display',component:DisplayComponent,outlet:'col2'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
